CREATE VIEW act_id_group AS
  SELECT
    `jeeadmin`.`sys_post`.`post_code` AS `ID_`,
    1                                 AS `REV_`,
    `jeeadmin`.`sys_post`.`post_name` AS `NAME_`,
    NULL                              AS `TYPE_`
  FROM `jeeadmin`.`sys_post`
  WHERE (`jeeadmin`.`sys_post`.`post_status` = 0);

