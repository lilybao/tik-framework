CREATE VIEW act_id_membership AS
  SELECT
    `jeeadmin`.`sys_user`.`login_name` AS `USER_ID_`,
    `jeeadmin`.`sys_post`.`post_code`  AS `GROUP_ID_`
  FROM ((`jeeadmin`.`sys_user_post`
    LEFT JOIN `jeeadmin`.`sys_post`
      ON ((`jeeadmin`.`sys_user_post`.`post_uuid` = `jeeadmin`.`sys_post`.`uuid`))) LEFT JOIN `jeeadmin`.`sys_user`
      ON ((`jeeadmin`.`sys_user_post`.`user_uuid` = `jeeadmin`.`sys_user`.`uuid`)))
  WHERE (`jeeadmin`.`sys_user`.`login_name` IS NOT NULL)
  ORDER BY `jeeadmin`.`sys_post`.`post_code`;

