CREATE VIEW act_id_user AS
  SELECT
    `jeeadmin`.`sys_user`.`login_name` AS `ID_`,
    1                                  AS `REV_`,
    `jeeadmin`.`sys_user`.`user_name`  AS `FIRST_`,
    NULL                               AS `LAST_`,
    NULL                               AS `EMAIL_`,
    NULL                               AS `PWD_`,
    NULL                               AS `PICTURE_ID_`
  FROM `jeeadmin`.`sys_user`
  WHERE (`jeeadmin`.`sys_user`.`user_status` = 0);

