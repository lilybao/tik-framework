CREATE VIEW act_id_info AS
  SELECT
    `jeeadmin`.`sys_user`.`login_name` AS `ID_`,
    NULL                               AS `REV_`,
    `jeeadmin`.`sys_user`.`login_name` AS `USER_ID_`,
    `jeeadmin`.`sys_post`.`post_code`  AS `TYPE_`,
    NULL                               AS `KEY_`,
    NULL                               AS `VALUE_`,
    NULL                               AS `PASSWORD_`,
    `jeeadmin`.`sys_user`.`org_uuid`   AS `PARENT_ID_`
  FROM ((`jeeadmin`.`sys_user`
    LEFT JOIN `jeeadmin`.`sys_user_post`
      ON ((`jeeadmin`.`sys_user`.`uuid` = `jeeadmin`.`sys_user_post`.`user_uuid`))) LEFT JOIN `jeeadmin`.`sys_post`
      ON ((`jeeadmin`.`sys_user_post`.`post_uuid` = `jeeadmin`.`sys_post`.`uuid`)));

